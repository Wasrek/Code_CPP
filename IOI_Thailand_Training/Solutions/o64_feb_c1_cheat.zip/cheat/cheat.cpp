#include<bits/stdc++.h>
using namespace std;

#include "cheat.h"

void cheat(int person1, int person2)
{
    
}

int investigate(int person1, int person2)
{
    return -1;
}

/*
5 4
C 1 2
C 2 1
C 3 1
C 4 100
I 3 2
I 1 100
C 3 4
I 1 100
I 1 2
*/