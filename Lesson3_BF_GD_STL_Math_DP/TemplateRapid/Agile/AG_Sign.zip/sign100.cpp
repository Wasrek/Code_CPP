/*
    TAG : Segment Tree, Constructive Algorithm
    Difficulty : 1 < 2 < 4 < 6 < 5 < 3
*/
#include<bits/stdc++.h>
using namespace std;
struct A{
    long long sum,num,ch,lz;
};
A tree[400010];
void init(long long k,long long l,long long r){
    if(l==r){
        tree[k]={l,1,0,0};
        return ;
    }
    long long mid=(l+r)/2;
    init(2*k,l,mid);
    init(2*k+1,mid+1,r);
    tree[k]={tree[2*k].sum+tree[2*k+1].sum,tree[2*k].num+tree[2*k+1].num,0,0};
}
void update(long long k,long long l,long long r,long long st,long long en,long long p){
    if(tree[k].ch==1){
        tree[k].ch=0;
        tree[k].sum=tree[k].lz*(r-l+1)*(r+l)/2;
        if(tree[k].lz==0) tree[k].num=0;
        else tree[k].num=r-l+1;
        if(l!=r){
            tree[2*k].ch=1;
            tree[2*k+1].ch=1;
            tree[2*k].lz=tree[k].lz;
            tree[2*k+1].lz=tree[k].lz;
        }
        tree[k].lz=0;
    }
    if(en<l||st>r) return;
    if(st<=l&&r<=en){
        tree[k].sum=p*(r-l+1)*(r+l)/2;
        if(p==1) tree[k].num=(r-l+1);
        else tree[k].num=0;
        if(l!=r){
            tree[2*k].ch=1;
            tree[2*k+1].ch=1;
            tree[2*k].lz=tree[k].lz;
            tree[2*k+1].lz=tree[k].lz;
        }
        return ;
    }
    long long mid=(l+r)/2;
    update(2*k,l,mid,st,en,p);
    update(2*k+1,mid+1,r,st,en,p);
    tree[k]={tree[2*k].sum+tree[2*k+1].sum,tree[2*k].num+tree[2*k+1].num,0,0};
}
long long querysum(long long k,long long l,long long r,long long st,long long en){
    if(tree[k].ch==1){
        tree[k].ch=0;
        tree[k].sum=tree[k].lz*(r-l+1)*(r+l)/2;
        if(tree[k].lz==0) tree[k].num=0;
        else tree[k].num=r-l+1;
        if(l!=r){
            tree[2*k].ch=1;
            tree[2*k+1].ch=1;
            tree[2*k].lz=tree[k].lz;
            tree[2*k+1].lz=tree[k].lz;
        }
        tree[k].lz=0;
    }
    if(en<l||st>r) return 0;
    if(st<=l&&r<=en) return tree[k].sum;
    long long mid=(l+r)/2;
    return querysum(2*k,l,mid,st,en)+querysum(2*k+1,mid+1,r,st,en);
}
long long querynum(long long k,long long l,long long r,long long st,long long en){
    if(tree[k].ch==1){
        tree[k].ch=0;
        tree[k].sum=tree[k].lz*(r-l+1)*(r+l)/2;
        if(tree[k].lz==0) tree[k].num=0;
        else tree[k].num=r-l+1;
        if(l!=r){
            tree[2*k].ch=1;
            tree[2*k+1].ch=1;
            tree[2*k].lz=tree[k].lz;
            tree[2*k+1].lz=tree[k].lz;
        }
        tree[k].lz=0;
    }
    if(en<l||st>r) return 0;
    if(st<=l&&r<=en) return tree[k].num;
    long long mid=(l+r)/2;
    return querynum(2*k,l,mid,st,en)+querynum(2*k+1,mid+1,r,st,en);
}
long long findp(long long k,long long l,long long r,long long p){
    if(tree[k].ch==1){
        tree[k].ch=0;
        tree[k].sum=tree[k].lz*(r-l+1)*(r+l)/2;
        if(tree[k].lz==0) tree[k].num=0;
        else tree[k].num=r-l+1;
        if(l!=r){
            tree[2*k].ch=1;
            tree[2*k+1].ch=1;
            tree[2*k].lz=tree[k].lz;
            tree[2*k+1].lz=tree[k].lz;
        }
        tree[k].lz=0;
    }
    if(l==r) return l;
    long long mid=(l+r)/2;
    if(tree[2*k].num>=p) return findp(2*k,l,mid,p);
    else return findp(2*k+1,mid+1,r,p-tree[2*k].num);
}
int main(){
    long long i,n,q,s,t,cnt,cntl,ans,p;
    scanf("%lld %lld",&n,&q);
    init(1,1,n);
    while(q--){
        scanf("%lld %lld",&s,&t);
        if(s==t) ans=1;
        else{
            cnt=querynum(1,1,n,s,t-1);
            ans=2*((t-s)*(t+s-1)/2-querysum(1,1,n,s,t-1))+cnt+1;
            if(s==1){
                ans=ans-(t-s-cnt);
            }else{
                cntl=querynum(1,1,n,1,s-1);
                if(cntl<=t-s-cnt){
                    ans=ans-2*querysum(1,1,n,1,s-1)-2*(t-s-cnt-cntl)+(t-s-cnt);
                    if(s!=2) update(1,1,n,2,s-1,0);
                }else{
                    p=findp(1,1,n,cntl-(t-s-cnt)+1);
                    ans=ans-2*querysum(1,1,n,p,s-1)+(t-s-cnt);
                    if(s!=2) update(1,1,n,p,s-1,0);
                }
            }
            if(s!=1) update(1,1,n,s,t-1,0);
            else if(t!=2) update(1,1,n,s+1,t-1,0);
        }
        p=querynum(1,1,n,t,t);
        if(p==0) update(1,1,n,t,t,1);
        else update(1,1,n,t,t,0);
        printf("%lld\n",ans);
    }
return 0;
}
/*
10 6
7 9
5 7
6 9
10 10
3 5
1 10
*/
