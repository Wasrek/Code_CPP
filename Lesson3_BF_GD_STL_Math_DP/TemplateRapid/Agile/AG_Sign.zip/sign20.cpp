#include<bits/stdc++.h>
using namespace std;
int state[100005],cnt;
void play(int now,int fin){
    int s=state[now];
    if(now!=1) state[now]=-state[now];
    cnt++;
    if(now==fin) return;
    else now=now+s,play(now,fin);
}
int main(){
    int i,n,q,s,t,ans,p;
    scanf("%d %d",&n,&q);
    for(i=1;i<=n;i++){
        state[i]=1;
    }
    while(q--){
        scanf("%d %d",&s,&t);
        cnt=0;
        play(s,t);
        printf("%d\n",cnt);
    }
return 0;
}
/*
10 6
7 9
5 7
6 9
10 10
3 5
1 10
*/
