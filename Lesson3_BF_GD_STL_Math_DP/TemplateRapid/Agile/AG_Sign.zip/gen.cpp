#include<bits/stdc++.h>
using namespace std;
int ran(int l,int r){
    return l+(rand()*rand())%(r-l+1);
}
int main(){
    srand(time(NULL));
    int n=100000,q=100000,i,j,s,t;
    freopen("20.in","w",stdout);
    printf("%d %d\n",n,q);
    while(q--){
        s=ran(1,n);
        t=ran(1,n);
        if(s>t) swap(s,t);
        printf("%d %d\n",s,t);
    }
return 0;
}
