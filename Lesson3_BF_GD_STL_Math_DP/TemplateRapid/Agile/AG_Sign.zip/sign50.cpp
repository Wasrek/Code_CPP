#include<bits/stdc++.h>
using namespace std;
int state[100005],cnt;
int main(){
    int i,n,q,s,t,now,p;
    scanf("%d %d",&n,&q);
    for(i=1;i<=n;i++){
        state[i]=1;
    }
    while(q--){
        scanf("%d %d",&s,&t);
        cnt=0;
        if(s==1){
            for(i=s;i<t;i++){
                if(state[i]==1) cnt++;
                else cnt+=((i-1)*2+1);
                if(i!=1&&state[i]==1) state[i]*=(-1);
            }
            cnt++;
            if(t!=1) state[t]*=(-1);
        }else{
            now=s-1;
            for(i=s;i<t;i++){
                if(state[i]==1) cnt++;
                else{
                    while(now>1&&state[now]==-1){
                        now--;
                    }
                    if(now!=1) state[now]*=(-1);
                    cnt+=((i-now)*2+1);
                }
                if(i!=1&&state[i]==1) state[i]*=(-1);
            }
            cnt++;
            if(t!=1) state[t]*=(-1);
        }
        printf("%d\n",cnt);
    }
return 0;
}
/*
10 6
7 9
5 7
6 9
10 10
3 5
1 10
*/
