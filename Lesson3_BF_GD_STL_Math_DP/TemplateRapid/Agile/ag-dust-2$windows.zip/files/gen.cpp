/*
    TASK:
    LANG: CPP
    AUTHOR: Wichada
*/
#include<bits/stdc++.h>
#include"testlib.h"
using namespace std;
#define maxN 200000
const int mi=-1e9, ma=1e9;
long long ran(long long l, long long r)
{
    // return l + (rand() % (r - l + 1));
    return rnd.next(l,r);
}
int main(int argc,char* argv[])
{
// int main(){
    // srand(time(0));
    registerGen(argc,argv,1);
    long long cnt=0,Q,N,I;
    long long maa,mii,xaa,xii;
    // scanf("%d %d %d",&Q,&N,&I);
    Q = atoi(argv[++cnt]);
	N = atoi(argv[++cnt]);
    I = atoi(argv[++cnt]);
    printf("%d\n",Q);
    while(Q--){
        long long n=ran(N-1,N);
        if(I<=2){
            n=ran(210,250);
        }
        long long ans=ran(1,n-100);
        // int ans=3;
        long long gr=n/ans;
        maa=mi+(int)2e9/ans-1;
        mii=mi;
        xaa=ma;
        xii=ma-(int)2e9/ans+1;
        printf("%d\n",n);
        for(int i=1;i<=n;i++){
             printf("%lld %lld\n",ran(xii+ma,xaa+ma)-ma,ran(mii+ma,maa+ma)-ma);
             if(i%gr==0){
                 mii+=(int)2e9/ans;
                 maa+=(int)2e9/ans;
                 xaa-=(int)2e9/ans;
                 xii-=(int)2e9/ans;
             }
        }
    }
    return 0;
}