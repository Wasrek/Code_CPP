long long dual_fuel(int n,int v,std::vector<int> &a, std::vector<int> &b);
