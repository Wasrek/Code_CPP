#include <vector>
#include "dual.h"

using namespace std;

long long dual_fuel(int n,int v,vector<int> &a, vector<int> &b) {

  return 0;
}
