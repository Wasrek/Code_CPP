#include "bestbank.h"
#include <vector>

void initialize(int N, int K,std::vector<std::vector<int> > R,std::vector<std::vector<long long> > B)
{
}

void update_bank(int P, int F,long long L)
{
}

long long find_best_bank(int S, int Y)
{
  return 0;
}

