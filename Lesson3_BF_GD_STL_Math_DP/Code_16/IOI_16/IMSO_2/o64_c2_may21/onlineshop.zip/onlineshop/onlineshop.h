void sell_all(int N);
bool sell_price(int P);
