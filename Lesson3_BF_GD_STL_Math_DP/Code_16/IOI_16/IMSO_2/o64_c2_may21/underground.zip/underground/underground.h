#include <vector>

int dig_paths(int R, int C,
	      std::vector<std::vector<int>>& A);
