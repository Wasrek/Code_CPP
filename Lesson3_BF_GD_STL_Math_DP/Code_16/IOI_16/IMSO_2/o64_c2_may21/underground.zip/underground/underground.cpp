#include "underground.h"

int dig_paths(int R, int C,
	      std::vector<std::vector<int>>& A)
{
  return 0;
}
