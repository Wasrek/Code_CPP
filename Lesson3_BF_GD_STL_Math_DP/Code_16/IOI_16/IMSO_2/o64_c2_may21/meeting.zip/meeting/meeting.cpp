#include<vector>
#include "meeting.h"

using namespace std;

vector<int> best_meeting(int N, int Q,
			 vector<vector<int>>& roads,
			 vector<int>& lengths,
			 vector<int>& a,
			 vector<int>& b,
			 vector<int>& c)
{
  vector<int> ans;
  return ans;
}
