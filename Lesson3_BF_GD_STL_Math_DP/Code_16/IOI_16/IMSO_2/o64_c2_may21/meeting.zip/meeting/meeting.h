#include<vector>

std::vector<int> best_meeting(int N, int Q,
			      std::vector<std::vector<int> >& roads,
			      std::vector<int>& lengths,
			      std::vector<int>& a,
			      std::vector<int>& b,
			      std::vector<int>& c);

