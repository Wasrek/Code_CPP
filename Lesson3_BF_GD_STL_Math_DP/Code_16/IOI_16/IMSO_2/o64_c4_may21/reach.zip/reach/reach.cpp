#include "reach.h"

void initialize(int N) {
	return;
}

void add_arc(int u, int v) {
	return;
}

bool is_reachable(int u, int v, int t) {
	return false;
}