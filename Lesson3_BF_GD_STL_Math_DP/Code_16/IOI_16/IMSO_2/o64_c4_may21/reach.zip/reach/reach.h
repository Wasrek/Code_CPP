void initialize(int N);

void add_arc(int u, int v);

bool is_reachable(int u, int v, int t);