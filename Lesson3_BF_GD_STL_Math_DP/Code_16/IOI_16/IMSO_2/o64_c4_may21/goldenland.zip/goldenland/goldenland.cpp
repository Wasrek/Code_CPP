#include <vector>

void init_land(int N, int M, int P, std::vector<int> A, std::vector<int> B){

}

long long answer_query(int r1, int c1, int r2, int c2){
	return 0ll;
}

