#include <vector>

int find_min_cost(int N, int M,
		  std::vector<int>& s,
		  std::vector<int>& t,
		  std::vector<int>& c);
