#include <vector>

int requeue(std::vector<int> Q, int k){
	return 0;
}
