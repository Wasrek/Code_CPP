#include <cstdio>
#include <vector>

int requeue(std::vector<int> Q, int k);
