#include <iostream>
#include <vector>
#include "sockslib.h"

using namespace std;

int main() {
  int n;
  n = num();
  vector<int> v = {1,2,3};
  cout << ask( v ) << endl;
  match(1,2);
}

