#ifndef __SOCKS_H__
#define __SOCKS_H__

#include <vector>

int num();
int ask(std::vector<int> &v);
bool match(int a,int b);

#endif
