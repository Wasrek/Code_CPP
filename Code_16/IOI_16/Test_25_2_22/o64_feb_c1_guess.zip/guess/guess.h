#include <utility>
#include <vector>

char ask(std::vector<std::pair<int, char> > query);
int find_answer(int N, int K);
