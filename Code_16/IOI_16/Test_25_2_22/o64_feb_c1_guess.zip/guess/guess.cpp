#include "guess.h"

int find_answer(int N, int K) {
  char c = ask({ { 0, 'R' } });
  return 1;
}