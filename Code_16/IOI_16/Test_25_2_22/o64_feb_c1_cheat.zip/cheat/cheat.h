void cheat(int person1, int person2);
int investigate(int person1, int person2);
