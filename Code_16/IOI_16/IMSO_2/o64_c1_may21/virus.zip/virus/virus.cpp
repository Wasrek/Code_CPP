#include "virus.h"

int n, x, y;

void initialize(int N, int X, int Y) {
  n = N, x = X, y = Y;
}

int ask(int L) {
  return n + x + y + L;
}