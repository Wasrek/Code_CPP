void initialize(int N, int X, int Y);
int ask(int L);
