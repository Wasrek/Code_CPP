#include <vector>

std::vector<std::vector<int>> build_graph(int N);
long long ask(int s, int t);
