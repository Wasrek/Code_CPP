#include "blindwalk.h"
#include <vector>

using namespace std;

vector<vector<int>> build_graph(int N)
{
  vector<vector<int>> out;

  out.push_back(vector<int>{0, 1, 1});

  return out;
}
